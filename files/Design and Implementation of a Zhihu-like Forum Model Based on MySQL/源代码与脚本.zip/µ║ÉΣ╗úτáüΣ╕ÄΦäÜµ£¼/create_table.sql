-- 创建用户表
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    nickname VARCHAR(50) NOT NULL UNIQUE,
    email_or_phone VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(50) NOT NULL,
    gender ENUM('male', 'female', 'other') NOT NULL,
    age INT CHECK (age >= 0 AND age <= 100) NOT NULL,
    profile VARCHAR(255),
    education VARCHAR(255),
    occupation VARCHAR(255)
);

-- 创建问题表
CREATE TABLE questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    asker_user_id INT,
    publish_time DATETIME,
    question_title VARCHAR(255) NOT NULL,
    question_content TEXT,
    click_count INT DEFAULT 0,
    FOREIGN KEY (asker_user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 创建回答表
CREATE TABLE answers (
    answer_id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT,
    responder_user_id INT,
    answer_time DATETIME,
    answer_content TEXT,
    click_count INT DEFAULT 0,
    FOREIGN KEY (responder_user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE
);

-- 创建会员表
CREATE TABLE members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE,
    remaining_time INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 创建文章表
CREATE TABLE articles (
    article_id INT AUTO_INCREMENT PRIMARY KEY,
    publish_member_id INT,
    article_title TEXT,
    article_content TEXT,
    submit_time DATETIME,
    click_count INT DEFAULT 0,
    FOREIGN KEY (publish_member_id) REFERENCES members(member_id) ON DELETE CASCADE
);

-- 插入用户数据
INSERT INTO users (nickname, email_or_phone, password, gender, age, profile, education, occupation) VALUES
('JohnDoe', 'john@example.com', 'password123', 'male', 28, 'A software engineer with a passion for technology.', 'Bachelor of Computer Science', 'Software Engineer'),
('JaneSmith', 'jane@example.com', 'pass456', 'female', 25, 'An aspiring artist exploring the world through creativity.', 'Bachelor of Fine Arts', 'Artist'),
('AliceWonder', 'alice@example.com', 'abc123', 'female', 35, 'An adventurous soul seeking new experiences and challenges.', 'Master of Business Administration', 'Entrepreneur');

-- 插入问题数据
INSERT INTO questions (asker_user_id, publish_time, question_title, question_content, click_count) VALUES
(1, NOW(), 'How to optimize SQL queries?', 'I am struggling with optimizing my SQL queries for better performance. Any tips or best practices?', 10),
(2, NOW(), 'What inspires your artwork?', 'I''m curious about what inspires different artists to create their artwork. Share your thoughts!', 15),
(3, NOW(), 'Starting a new business venture', 'I am thinking about starting my own business but not sure where to begin. Any advice for aspiring entrepreneurs?', 8);

-- 插入回答数据
INSERT INTO answers (question_id, responder_user_id, answer_time, answer_content, click_count) VALUES
(1, 3, NOW(), 'One way to optimize SQL queries is to ensure proper indexing on frequently queried columns. Additionally, avoiding unnecessary joins and using efficient WHERE clauses can help improve performance.', 5),
(2, 1, NOW(), 'Nature and everyday life inspire my artwork. I find beauty and meaning in the simplest of things, and I try to reflect that in my creations.', 7),
(3, 2, NOW(), 'Starting a new business can be daunting but also exciting. My advice would be to start with a solid business plan, conduct market research, and seek mentorship from experienced entrepreneurs.', 12);

-- 插入会员数据
INSERT INTO members (user_id, remaining_time) VALUES
(1, 30),
(3, 20);

-- 插入文章数据
INSERT INTO articles (publish_member_id, article_title, article_content, submit_time, click_count) VALUES
(1, 'SQL Optimization', 'A Beginner''s Guide to SQL Optimization', NOW(), 20),
(2, 'Journey', 'The Entrepreneurial Journey: From Idea to Execution', NOW(), 18);
