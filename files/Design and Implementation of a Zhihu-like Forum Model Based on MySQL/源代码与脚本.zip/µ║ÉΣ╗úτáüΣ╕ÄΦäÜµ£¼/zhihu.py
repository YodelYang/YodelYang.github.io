from flask import Flask, render_template, request, redirect, url_for, session
import pymysql
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'zhihu_system'

db = pymysql.connect(
    host='localhost',
    user='root',
    password='H952126037',
    database='zhihu_system'
)
cursor = db.cursor()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email_or_phone = request.form['email_or_phone']
        password = request.form['password']
        
        cursor.execute("SELECT user_id FROM users WHERE email_or_phone = %s AND password = %s", (email_or_phone, password))
        user = cursor.fetchone()
        
        if user:
            session['user_id'] = user[0]
            session['guest'] = False
            return redirect(url_for('questions'))
        else:
            return render_template('login.html', message="用户名或密码错误，请重试")

    message = request.args.get('message')
    return render_template('login.html', message=message)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        nickname = request.form['nickname']
        email_or_phone = request.form['email_or_phone']
        password = request.form['password']
        gender = request.form['gender']
        age = request.form['age']
        profile = request.form.get('profile')
        education = request.form.get('education')
        occupation = request.form.get('occupation')

        cursor.execute("""
            INSERT INTO users (nickname, email_or_phone, password, gender, age, profile, education, occupation)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (nickname, email_or_phone, password, gender, age, profile, education, occupation))
        db.commit()

        cursor.execute("SELECT LAST_INSERT_ID()")
        user_id = cursor.fetchone()[0]
        
        session['user_id'] = user_id
        return redirect(url_for('questions'))
    
    return render_template('register.html')

@app.route('/guest')
def guest():
    session['guest'] = True
    return redirect(url_for('questions'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/questions')
def questions():
    cursor.execute("SELECT q.question_id, q.question_title, q.question_content, q.publish_time, q.click_count, u.nickname \
                    FROM questions q JOIN users u ON q.asker_user_id = u.user_id")
    questions = cursor.fetchall()

    for question in questions:
        question_id = question[0]
        cursor.execute("UPDATE questions SET click_count = click_count + 1 WHERE question_id = %s", (question_id,))
        db.commit()
    
    return render_template('questions.html', questions=questions)

@app.route('/ask_question', methods=['GET', 'POST'])
def ask_question():
    if 'guest' in session and session['guest']:
        return redirect(url_for('login', message="请先登录以提出问题", next=url_for('ask_question')))
    
    if request.method == 'POST':
        asker_user_id = session['user_id']
        question_title = request.form['question_title']
        question_content = request.form['question_content']
        
        cursor.execute("INSERT INTO questions (asker_user_id, publish_time, question_title, question_content) VALUES (%s, NOW(), %s, %s)",
                       (asker_user_id, question_title, question_content))
        db.commit()
        
        return redirect(url_for('questions'))
    
    return render_template('ask_question.html')


@app.route('/view_answers/<int:question_id>')
def view_answers(question_id):
    cursor.execute("SELECT a.answer_content, a.answer_time, a.click_count, u.nickname, a.answer_id\
                    FROM answers a JOIN users u ON a.responder_user_id = u.user_id \
                    WHERE a.question_id = %s", (question_id,))
    answers = cursor.fetchall()
    for answer in answers:
        answer_id = answer[4]
        cursor.execute("UPDATE answers SET click_count = click_count + 1 WHERE answer_id = %s", (answer_id,))
        db.commit()

    return render_template('view_answers.html', answers=answers, question_id=question_id)


@app.route('/answer/<int:question_id>', methods=['GET', 'POST'])
def answer(question_id):
    if 'guest' in session and session['guest']:
        return redirect(url_for('login', message="请先登录以回答问题"))

    
    if request.method == 'POST':
        answer_content = request.form['answer_content']
        user_id = session['user_id']
        answer_time = datetime.now()

        cursor.execute("INSERT INTO answers (responder_user_id, question_id, answer_content, answer_time) VALUES (%s, %s, %s, %s)",
                       (user_id, question_id, answer_content, answer_time))
        db.commit()
        
        return redirect(url_for('questions'))
    
    return render_template('answer.html', question_id=question_id)


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'guest' in session and session['guest']:
        return redirect(url_for('login', message="请先登录以查看用户信息"))
    
    user_id = session['user_id']
    
    if request.method == 'POST':
        if 'update' in request.form:
            nickname = request.form['nickname']
            email_or_phone = request.form['email_or_phone']
            gender = request.form['gender']
            age = request.form['age']
            profile = request.form['profile']
            education = request.form['education']
            occupation = request.form['occupation']
            
            # 更新用户信息
            cursor.execute("""
                UPDATE users SET nickname = %s, email_or_phone = %s, gender = %s, age = %s, profile = %s, education = %s, occupation = %s
                WHERE user_id = %s
            """, (nickname, email_or_phone, gender, age, profile, education, occupation, user_id))
            db.commit()
        
        return redirect(url_for('questions'))

    cursor.execute("SELECT nickname, email_or_phone, gender, age, profile, education, occupation FROM users WHERE user_id = %s", (user_id,))
    user = cursor.fetchone()

    cursor.execute("SELECT remaining_time FROM members WHERE user_id = %s", (user_id,))
    member = cursor.fetchone()
    
    message = request.args.get('message')
    
    return render_template('profile.html', user=user, member=member, message=message)


@app.route('/articles')
def articles():
    if 'guest' in session and session['guest']:
        return redirect(url_for('login', message="请先登录以查看文章"))
    
    user_id = session['user_id']
    
    cursor.execute("SELECT * FROM members WHERE user_id = %s", (user_id,))
    member = cursor.fetchone()
    
    if not member:
        return redirect(url_for('subscribe', message="您不是会员，请先充值"))
    
    cursor.execute("SELECT a.article_title, a.article_content, a.submit_time, a.click_count, u.nickname, article_id \
                    FROM articles a JOIN members m ON a.publish_member_id = m.member_id \
                    JOIN users u ON m.user_id = u.user_id")
    articles = cursor.fetchall()
    for article in articles:
        article_id = article[5]
        cursor.execute("UPDATE articles SET click_count = click_count + 1 WHERE article_id = %s", (article_id,))
        db.commit()
    
    return render_template('articles.html', articles=articles)

@app.route('/publish_article', methods=['GET', 'POST'])
def publish_article():
    user_id = session['user_id']
    
    cursor.execute("SELECT member_id FROM members WHERE user_id = %s", (user_id,))
    member = cursor.fetchone()

    
    if request.method == 'POST':
        article_title = request.form['article_title']
        article_content = request.form['article_content']
        publish_member_id = member[0]
        
        cursor.execute("INSERT INTO articles (publish_member_id, article_title, article_content, submit_time) VALUES (%s, %s, %s, NOW())", 
                       (publish_member_id, article_title, article_content))
        db.commit()
        
        return redirect(url_for('articles'))
    
    return render_template('publish_article.html')



@app.route('/subscribe', methods=['GET', 'POST'])
def subscribe():
    if 'user_id' not in session:
        return redirect(url_for('login', message="请先登录以充值会员"))

    user_id = session['user_id']
    
    if request.method == 'POST':
        duration = int(request.form['duration'])

        cursor.execute("INSERT INTO members (user_id, remaining_time) VALUES (%s, %s) ON DUPLICATE KEY UPDATE remaining_time = remaining_time + %s",
                       (user_id, duration, duration))
        db.commit()
        
        return redirect(url_for('profile', message=f"充值成功，您已充值 {duration} 天"))

    message = request.args.get('message')
    return render_template('subscribe.html', message=message)

@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('search_query')
    if not query:
        return render_template('search_results.html', message="请提供一个搜索查询")
    
    cursor.execute("SELECT q.question_id, q.question_title, q.question_content, q.publish_time, q.click_count, u.nickname \
                    FROM questions q JOIN users u ON q.asker_user_id = u.user_id \
                    WHERE q.question_title LIKE %s", ('%' + query + '%',))
    results = cursor.fetchall()
    
    if not results:
        message = "没有找到匹配的问题"
        return render_template('search_results.html', message=message)
    
    return render_template('search_results.html', questions=results)

    

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email_or_phone = request.form['email_or_phone']
        new_password = request.form['new_password']

        cursor.execute("UPDATE users SET password = %s WHERE email_or_phone = %s", (new_password, email_or_phone))
        db.commit()
        cursor.execute("SELECT user_id FROM users WHERE email_or_phone = %s AND password = %s", (email_or_phone, new_password))
        user = cursor.fetchone()
        
        if user:
            session['user_id'] = user[0]
            session['guest'] = False
            return redirect(url_for('questions'))
        
        return redirect(url_for('questions'))
    
    return render_template('forgot_password.html')


if __name__ == '__main__':
    app.run(debug=True)
