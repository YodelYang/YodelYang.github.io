import numpy as np
from segment_anything import sam_model_registry, SamPredictor

import importlib
import sys
import os

sys.path.append('.')
sys.path.append('..')

import cv2
import argparse
from PIL import Image
from skimage.morphology.binary import binary_dilation

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import transforms

from networks.models import build_vos_model
from networks.engines import build_engine
from utils.checkpoint import load_network

from dataloaders.eval_datasets import VOSTest
import dataloaders.video_transforms as tr
from utils.image import save_mask

aot_ckpt = "./weights/"
sam_checkpot = "./weights/sam_vit_h_4b8939.pth"
sam_model_type = "vit_h"

device = "cuda"


class ikunet():
    
    def __init__(self, sam_checkpoint, sam_model_type, aot_ckpt ,device):
        sam = sam_model_registry[sam_model_type](checkpoint=sam_checkpoint)
        sam.to(device=device)

        self.predictor = SamPredictor(sam)
        
        parser = argparse.ArgumentParser(description="ikunet demo")
        parser.add_argument('--exp_name', type=str, default='default')

        parser.add_argument('--stage', type=str, default='pre_ytb_dav')
        parser.add_argument('--model', type=str, default='r50_aotl')

        parser.add_argument('--gpu_id', type=int, default=0)

        parser.add_argument('--data_path', type=str, default='./output/')
        parser.add_argument('--output_path', type=str, default='./demo_output')
        parser.add_argument('--ckpt_path',
                            type=str,
                            default=aot_ckpt)

        parser.add_argument('--max_resolution', type=float, default=480 * 1.3)

        parser.add_argument('--amp', action='store_true')
        parser.set_defaults(amp=False)

        args = parser.parse_args()

        engine_config = importlib.import_module('configs.' + args.stage)
        self.cfg = engine_config.EngineConfig(args.exp_name, args.model)

        self.cfg.TEST_GPU_ID = args.gpu_id

        self.cfg.TEST_CKPT_PATH = args.ckpt_path
        self.cfg.TEST_DATA_PATH = args.data_path
        self.cfg.TEST_OUTPUT_PATH = args.output_path

        self.cfg.TEST_MIN_SIZE = None
        self.cfg.TEST_MAX_SIZE = args.max_resolution * 800. / 480.


    def segment_with_point(self, img, point):
        """
        img --- a cv2 image instance with RGB model
        point --- np.array
        """
        self.predictor.set_image(img)
        masks, scores, _ = self.predictor.predict(
            point_coords=point,
            point_labels=np.array([1]),
            multimask_output=True,
        )
        best_mask = masks[np.argmax(scores), :, :]
        print(best_mask.shape)
        return best_mask

    
    def segment_video(self, video_path):
        video_fps = 15
        gpu_id = self.cfg.TEST_GPU_ID

        model = build_vos_model(cfg.MODEL_VOS, cfg).cuda(gpu_id)

        model, _ = load_network(model, cfg.TEST_CKPT_PATH, gpu_id)

        engine = build_engine(cfg.MODEL_ENGINE,
                              phase='eval',
                              aot_model=model,
                              gpu_id=gpu_id,
                              long_term_mem_gap=cfg.TEST_LONG_TERM_MEM_GAP)

        # Prepare datasets for each sequence
        transform = transforms.Compose([
            tr.MultiRestrictSize(cfg.TEST_MIN_SIZE, cfg.TEST_MAX_SIZE,
                                 cfg.TEST_FLIP, cfg.TEST_MULTISCALE,
                                 cfg.MODEL_ALIGN_CORNERS),
            tr.MultiToTensor()
        ])
        image_root = os.path.join(cfg.TEST_DATA_PATH, 'images')
        label_root = os.path.join(cfg.TEST_DATA_PATH, 'masks')

        sequences = os.listdir(image_root)
        seq_datasets = []
        for seq_name in sequences:
            print('Build a dataset for sequence {}.'.format(seq_name))
            seq_images = np.sort(os.listdir(os.path.join(image_root, seq_name)))
            seq_labels = [seq_images[0].replace('jpg', 'png')]
            seq_dataset = VOSTest(image_root,
                                  label_root,
                                  seq_name,
                                  seq_images,
                                  seq_labels,
                                  transform=transform)
            seq_datasets.append(seq_dataset)

        # Infer
        output_root = cfg.TEST_OUTPUT_PATH
        output_mask_root = os.path.join(output_root, 'pred_masks')
        if not os.path.exists(output_mask_root):
            os.makedirs(output_mask_root)

        for seq_dataset in seq_datasets:
            seq_name = seq_dataset.seq_name
            image_seq_root = os.path.join(image_root, seq_name)
            output_mask_seq_root = os.path.join(output_mask_root, seq_name)
            if not os.path.exists(output_mask_seq_root):
                os.makedirs(output_mask_seq_root)
            print('Build a dataloader for sequence {}.'.format(seq_name))
            seq_dataloader = DataLoader(seq_dataset,
                                        batch_size=1,
                                        shuffle=False,
                                        num_workers=cfg.TEST_WORKERS,
                                        pin_memory=True)


            print('Start the inference of sequence {}:'.format(seq_name))
            model.eval()
            engine.restart_engine()
            with torch.no_grad():
                for frame_idx, samples in enumerate(seq_dataloader):
                    sample = samples[0]
                    img_name = sample['meta']['current_name'][0]

                    obj_nums = sample['meta']['obj_num']
                    output_height = sample['meta']['height']
                    output_width = sample['meta']['width']
                    obj_idx = sample['meta']['obj_idx']

                    obj_nums = [int(obj_num) for obj_num in obj_nums]
                    obj_idx = [int(_obj_idx) for _obj_idx in obj_idx]

                    current_img = sample['current_img']
                    current_img = current_img.cuda(gpu_id, non_blocking=True)

                    if frame_idx == 0:
                        videoWriter = cv2.VideoWriter(
                            output_video_path, fourcc, video_fps,
                            (int(output_width), int(output_height)))
                        print(
                            'Object number: {}. Inference size: {}x{}. Output size: {}x{}.'
                            .format(obj_nums[0],
                                    current_img.size()[2],
                                    current_img.size()[3], int(output_height),
                                    int(output_width)))
                        current_label = sample['current_label'].cuda(
                            gpu_id, non_blocking=True).float()
                        current_label = F.interpolate(current_label,
                                                      size=current_img.size()[2:],
                                                      mode="nearest")
                        # add reference frame
                        engine.add_reference_frame(current_img,
                                                   current_label,
                                                   frame_step=0,
                                                   obj_nums=obj_nums)
                    else:
                        print('Processing image {}...'.format(img_name))
                        # predict segmentation
                        engine.match_propogate_one_frame(current_img)
                        pred_logit = engine.decode_current_logits(
                            (output_height, output_width))
                        pred_prob = torch.softmax(pred_logit, dim=1)
                        pred_label = torch.argmax(pred_prob, dim=1,
                                                  keepdim=True).float()
                        _pred_label = F.interpolate(pred_label,
                                                    size=engine.input_size_2d,
                                                    mode="nearest")
                        # update memory
                        engine.update_memory(_pred_label)

                        # save results
                        input_image_path = os.path.join(image_seq_root, img_name)
                        output_mask_path = os.path.join(
                            output_mask_seq_root,
                            img_name.split('.')[0] + '.png')

                        pred_label = Image.fromarray(
                            pred_label.squeeze(0).squeeze(0).cpu().numpy().astype(
                                'uint8')).convert('P')
                        pred_label.putpalette(_palette)
                        pred_label.save(output_mask_path)


            print('Save a visualization video to {}.'.format(output_video_path))
    
    
    def predict(self, video_path, points):
        cap = cv2.VideoCapture(video_path)
    
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        video_fps = int(cap.get(cv2.CAP_PROP_FPS))
        
        print(total_frames, video_fps)
        video_name = video_path.split("/")[-1].split(".")[0]
        output_path = f'./frames/images/{video_name}'
        
        print(f"Process video {video_name}")
        os.makedirs(output_path, exist_ok=True)
        
        frame_index = 0
        while frame_index < total_frames:
            ret, frame = cap.read()
            image_path = os.path.join(output_path, f"frame_{frame_index:04d}.png")
            cv2.imwrite(image_path, frame)
            frame_index += 1

        cap.release()
        
        ##SAM
        print(f"SAM")
        
        init_mask_path = f'./frames/masks/{video_name}'
        os.makedirs(init_mask_path, exist_ok=True)
        image_list = os.listdir(output_path)
        image_list = sorted(image_list)
        init_image = image_list[0]
        img = cv2.imread(os.path.join(output_path, init_image))
        init_mask = self.segment_with_point(img, points)
        h, w = mask.shape[-2:]
        init_mask = mask.reshape(h, w, 1)
        cv2.imwrite(os.path.join(init_mask_path, init_image), init_mask)
        
        ##AOT
        
        
    
    
    
if __name__ == "__main__":
    
    point = np.array([[1170, 920]])
    model = ikunet(sam_checkpot, sam_model_type, aot_ckpt, device)
    model.predict("./videos/test.mp4", point)