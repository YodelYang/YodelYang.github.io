import numpy as np
from segment_anything import sam_model_registry, SamPredictor

import importlib
import sys
import os
import gc

sys.path.append('.')
sys.path.append('..')

import cv2
import time
import argparse
from tqdm import tqdm
from PIL import Image
from skimage.morphology.binary import binary_dilation

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import transforms

from networks.models import build_vos_model
from networks.engines import build_engine
from utils.checkpoint import load_network

from dataloaders.eval_datasets import VOSTest
import dataloaders.video_transforms as tr
from utils.image import save_mask

aot_ckpt = "./weights/R50_AOTL_PRE_YTB_DAV.pth"
sam_checkpot = "./weights/sam_vit_h_4b8939.pth"
sam_model_type = "vit_h"

device = "cuda"

_palette = [
    255, 0, 0, 0, 0, 139, 255, 255, 84, 0, 255, 0, 139, 0, 139, 0, 128, 128,
    128, 128, 128, 139, 0, 0, 218, 165, 32, 144, 238, 144, 160, 82, 45, 148, 0,
    211, 255, 0, 255, 30, 144, 255, 255, 218, 185, 85, 107, 47, 255, 140, 0,
    50, 205, 50, 123, 104, 238, 240, 230, 140, 72, 61, 139, 128, 128, 0, 0, 0,
    205, 221, 160, 221, 143, 188, 143, 127, 255, 212, 176, 224, 230, 244, 164,
    96, 250, 128, 114, 70, 130, 180, 0, 128, 0, 173, 255, 47, 255, 105, 180,
    238, 130, 238, 154, 205, 50, 220, 20, 60, 176, 48, 96, 0, 206, 209, 0, 191,
    255, 40, 40, 40, 41, 41, 41, 42, 42, 42, 43, 43, 43, 44, 44, 44, 45, 45,
    45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 51, 51, 51,
    52, 52, 52, 53, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 58,
    58, 58, 59, 59, 59, 60, 60, 60, 61, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64,
    64, 65, 65, 65, 66, 66, 66, 67, 67, 67, 68, 68, 68, 69, 69, 69, 70, 70, 70,
    71, 71, 71, 72, 72, 72, 73, 73, 73, 74, 74, 74, 75, 75, 75, 76, 76, 76, 77,
    77, 77, 78, 78, 78, 79, 79, 79, 80, 80, 80, 81, 81, 81, 82, 82, 82, 83, 83,
    83, 84, 84, 84, 85, 85, 85, 86, 86, 86, 87, 87, 87, 88, 88, 88, 89, 89, 89,
    90, 90, 90, 91, 91, 91, 92, 92, 92, 93, 93, 93, 94, 94, 94, 95, 95, 95, 96,
    96, 96, 97, 97, 97, 98, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101,
    102, 102, 102, 103, 103, 103, 104, 104, 104, 105, 105, 105, 106, 106, 106,
    107, 107, 107, 108, 108, 108, 109, 109, 109, 110, 110, 110, 111, 111, 111,
    112, 112, 112, 113, 113, 113, 114, 114, 114, 115, 115, 115, 116, 116, 116,
    117, 117, 117, 118, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121,
    122, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126,
    127, 127, 127, 128, 128, 128, 129, 129, 129, 130, 130, 130, 131, 131, 131,
    132, 132, 132, 133, 133, 133, 134, 134, 134, 135, 135, 135, 136, 136, 136,
    137, 137, 137, 138, 138, 138, 139, 139, 139, 140, 140, 140, 141, 141, 141,
    142, 142, 142, 143, 143, 143, 144, 144, 144, 145, 145, 145, 146, 146, 146,
    147, 147, 147, 148, 148, 148, 149, 149, 149, 150, 150, 150, 151, 151, 151,
    152, 152, 152, 153, 153, 153, 154, 154, 154, 155, 155, 155, 156, 156, 156,
    157, 157, 157, 158, 158, 158, 159, 159, 159, 160, 160, 160, 161, 161, 161,
    162, 162, 162, 163, 163, 163, 164, 164, 164, 165, 165, 165, 166, 166, 166,
    167, 167, 167, 168, 168, 168, 169, 169, 169, 170, 170, 170, 171, 171, 171,
    172, 172, 172, 173, 173, 173, 174, 174, 174, 175, 175, 175, 176, 176, 176,
    177, 177, 177, 178, 178, 178, 179, 179, 179, 180, 180, 180, 181, 181, 181,
    182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186,
    187, 187, 187, 188, 188, 188, 189, 189, 189, 190, 190, 190, 191, 191, 191,
    192, 192, 192, 193, 193, 193, 194, 194, 194, 195, 195, 195, 196, 196, 196,
    197, 197, 197, 198, 198, 198, 199, 199, 199, 200, 200, 200, 201, 201, 201,
    202, 202, 202, 203, 203, 203, 204, 204, 204, 205, 205, 205, 206, 206, 206,
    207, 207, 207, 208, 208, 208, 209, 209, 209, 210, 210, 210, 211, 211, 211,
    212, 212, 212, 213, 213, 213, 214, 214, 214, 215, 215, 215, 216, 216, 216,
    217, 217, 217, 218, 218, 218, 219, 219, 219, 220, 220, 220, 221, 221, 221,
    222, 222, 222, 223, 223, 223, 224, 224, 224, 225, 225, 225, 226, 226, 226,
    227, 227, 227, 228, 228, 228, 229, 229, 229, 230, 230, 230, 231, 231, 231,
    232, 232, 232, 233, 233, 233, 234, 234, 234, 235, 235, 235, 236, 236, 236,
    237, 237, 237, 238, 238, 238, 239, 239, 239, 240, 240, 240, 241, 241, 241,
    242, 242, 242, 243, 243, 243, 244, 244, 244, 245, 245, 245, 246, 246, 246,
    247, 247, 247, 248, 248, 248, 249, 249, 249, 250, 250, 250, 251, 251, 251,
    252, 252, 252, 253, 253, 253, 254, 254, 254, 255, 255, 255, 0, 0, 0
]
color_palette = np.array(_palette).reshape(-1, 3)


def to_tensors():
    return transforms.Compose([Stack(), ToTorchFormatTensor()])


class Stack(object):
    def __init__(self, roll=False):
        self.roll = roll

    def __call__(self, img_group):
        mode = img_group[0].mode
        if mode == '1':
            img_group = [img.convert('L') for img in img_group]
            mode = 'L'
        if mode == 'L':
            return np.stack([np.expand_dims(x, 2) for x in img_group], axis=2)
        elif mode == 'RGB':
            if self.roll:
                return np.stack([np.array(x)[:, :, ::-1] for x in img_group],
                                axis=2)
            else:
                return np.stack(img_group, axis=2)
        else:
            raise NotImplementedError(f"Image mode {mode}")


class ToTorchFormatTensor(object):
    """ Converts a PIL.Image (RGB) or numpy.ndarray (H x W x C) in the range [0, 255]
    to a torch.FloatTensor of shape (C x H x W) in the range [0.0, 1.0] """
    def __init__(self, div=True):
        self.div = div

    def __call__(self, pic):
        if isinstance(pic, np.ndarray):
            # numpy img: [L, C, H, W]
            img = torch.from_numpy(pic).permute(2, 3, 0, 1).contiguous()
        else:
            # handle PIL Image
            img = torch.ByteTensor(torch.ByteStorage.from_buffer(
                pic.tobytes()))
            img = img.view(pic.size[1], pic.size[0], len(pic.mode))
            # put it from HWC to CHW format
            # yikes, this transpose takes 80% of the loading time/CPU
            img = img.transpose(0, 1).transpose(0, 2).contiguous()
        img = img.float().div(255) if self.div else img.float()
        return img


# sample reference frames from the whole video
def get_ref_index(f, neighbor_ids, length, num_ref, ref_length):
    ref_index = []
    if num_ref == -1:
        for i in range(0, length, ref_length):
            if i not in neighbor_ids:
                ref_index.append(i)
    else:
        start_idx = max(0, f - ref_length * (num_ref // 2))
        end_idx = min(length, f + ref_length * (num_ref // 2))
        for i in range(start_idx, end_idx + 1, ref_length):
            if i not in neighbor_ids:
                if len(ref_index) > num_ref:
                    break
                ref_index.append(i)
    return ref_index


# read frame-wise masks
def read_mask(mpath, size):
    masks = []
    mnames = os.listdir(mpath)
    mnames.sort()
    for mp in mnames:
        m = Image.open(os.path.join(mpath, mp))
        m = m.resize(size, Image.NEAREST)
        m = np.array(m.convert('L'))
        m = np.array(m > 0).astype(np.uint8)
        m = cv2.dilate(m,
                       cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3)),
                       iterations=4)
        masks.append(Image.fromarray(m * 255))
    return masks


#  read frames from video
def read_frame_from_videos(args):
    vname = args.video
    frames = []
    if args.use_mp4:
        vidcap = cv2.VideoCapture(vname)
        success, image = vidcap.read()
        count = 0
        while success:
            image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            frames.append(image)
            success, image = vidcap.read()
            count += 1
    else:
        lst = os.listdir(vname)
        lst.sort()
        fr_lst = [vname + '/' + name for name in lst]
        for fr in fr_lst:
            image = cv2.imread(fr)
            image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            frames.append(image)
    return frames


# resize frames
def resize_frames(frames, size=None):
    if size is not None:
        frames = [f.resize(size) for f in frames]
    else:
        size = frames[0].size
    return frames, size


class ikunet():
    
    def __init__(self, sam_checkpoint, sam_model_type, aot_ckpt ,device):

        ##SAM config
        sam = sam_model_registry[sam_model_type](checkpoint=sam_checkpoint)
        sam.to(device=device)

        self.predictor = SamPredictor(sam)
        
        ##args for AOT
        parser = argparse.ArgumentParser(description="ikunet demo")
        parser.add_argument('--exp_name', type=str, default='default')

        parser.add_argument('--stage', type=str, default='pre_ytb_dav')
        parser.add_argument('--model', type=str, default='r50_aotl')

        parser.add_argument('--gpu_id', type=int, default=0)

        parser.add_argument('--data_path', type=str, default='./output/')
        parser.add_argument('--output_path', type=str, default='./demo_output')
        parser.add_argument('--ckpt_path',
                            type=str,
                            default=aot_ckpt)

        parser.add_argument('--max_resolution', type=float, default=480 * 1.3)

        parser.add_argument('--amp', action='store_true')
        parser.set_defaults(amp=False)

        ##args for e2fgvi
        parser.add_argument("-v", "--video", type=str)
        parser.add_argument("-c", "--ckpt", type=str, default='./weights/E2FGVI-CVPR22.pth')
        parser.add_argument("-m", "--mask", type=str)
        parser.add_argument("--e2_model", type=str, default='e2fgvi')
        parser.add_argument("--step", type=int, default=10)
        parser.add_argument("--num_ref", type=int, default=-1)
        parser.add_argument("--neighbor_stride", type=int, default=5)
        parser.add_argument("--savefps", type=int, default=24)

        # args for e2fgvi_hq (which can handle videos with arbitrary resolution)
        parser.add_argument("--set_size", action='store_true', default=True)
        parser.add_argument("--width", type=int)
        parser.add_argument("--height", type=int)

        self.args = parser.parse_args()

        ##AOT config
        engine_config = importlib.import_module('configs.' + self.args.stage)
        self.cfg = engine_config.EngineConfig(self.args.exp_name, self.args.model)

        self.cfg.TEST_GPU_ID = self.args.gpu_id

        self.cfg.TEST_CKPT_PATH = self.args.ckpt_path
        self.cfg.TEST_DATA_PATH = self.args.data_path
        self.cfg.TEST_OUTPUT_PATH = self.args.output_path

        self.cfg.TEST_MIN_SIZE = None
        self.cfg.TEST_MAX_SIZE = self.args.max_resolution * 800. / 480.

        ##E2FGI config
        self.ref_length = self.args.step  # ref_step
        self.num_ref = self.args.num_ref
        self.neighbor_stride = self.args.neighbor_stride
        self.default_fps = self.args.savefps

        self.device = device


    def segment_with_point(self, img, point):
        """
        img --- a cv2 image instance with RGB model
        point --- np.array
        """
        self.predictor.set_image(img)
        masks, scores, _ = self.predictor.predict(
            point_coords=point,
            point_labels=np.array([1]),
            multimask_output=True,
        )
        best_mask = masks[np.argmax(scores), :, :]
        print(best_mask.shape)
        return best_mask

    
    def segment_video(self, video_name):
        gpu_id = self.cfg.TEST_GPU_ID
        self.cfg.TEST_DATA_PATH = f'./frames/{video_name}'
        self.cfg.TEST_OUTPUT_PATH = f'./frames/{video_name}/masks/sequence1'
        model = build_vos_model(self.cfg.MODEL_VOS, self.cfg).cuda(gpu_id)

        model, _ = load_network(model, self.cfg.TEST_CKPT_PATH, gpu_id)

        engine = build_engine(self.cfg.MODEL_ENGINE,
                              phase='eval',
                              aot_model=model,
                              gpu_id=gpu_id,
                              long_term_mem_gap=self.cfg.TEST_LONG_TERM_MEM_GAP)

        # Prepare datasets for each sequence
        transform = transforms.Compose([
            tr.MultiRestrictSize(self.cfg.TEST_MIN_SIZE, self.cfg.TEST_MAX_SIZE,
                                 self.cfg.TEST_FLIP, self.cfg.TEST_MULTISCALE,
                                 self.cfg.MODEL_ALIGN_CORNERS),
            tr.MultiToTensor()
        ])
        image_root = os.path.join(self.cfg.TEST_DATA_PATH, 'images')
        label_root = os.path.join(self.cfg.TEST_DATA_PATH, 'masks')

        sequences = os.listdir(image_root)
        seq_datasets = []
        for seq_name in sequences:
            print('Build a dataset for sequence {}.'.format(seq_name))
            seq_images = np.sort(os.listdir(os.path.join(image_root, seq_name)))
            seq_labels = [seq_images[0].replace('jpg', 'png')]
            seq_dataset = VOSTest(image_root,
                                  label_root,
                                  seq_name,
                                  seq_images,
                                  seq_labels,
                                  transform=transform)
            seq_datasets.append(seq_dataset)

        # Infer
        output_root = self.cfg.TEST_OUTPUT_PATH
        output_mask_root = output_root
        if not os.path.exists(output_mask_root):
            os.makedirs(output_mask_root)

        for seq_dataset in seq_datasets:
            seq_name = seq_dataset.seq_name
            output_mask_seq_root = output_mask_root
            if not os.path.exists(output_mask_seq_root):
                os.makedirs(output_mask_seq_root)
            print('Build a dataloader for sequence {}.'.format(seq_name))
            seq_dataloader = DataLoader(seq_dataset,
                                        batch_size=1,
                                        shuffle=False,
                                        num_workers=self.cfg.TEST_WORKERS,
                                        pin_memory=True)


            print('Start the inference of sequence {}:'.format(seq_name))
            model.eval()
            engine.restart_engine()
            with torch.no_grad():
                for frame_idx, samples in enumerate(seq_dataloader):
                    sample = samples[0]
                    img_name = sample['meta']['current_name'][0]

                    obj_nums = sample['meta']['obj_num']
                    output_height = sample['meta']['height']
                    output_width = sample['meta']['width']
                    obj_idx = sample['meta']['obj_idx']

                    obj_nums = [int(obj_num) for obj_num in obj_nums]
                    obj_idx = [int(_obj_idx) for _obj_idx in obj_idx]

                    current_img = sample['current_img']
                    current_img = current_img.cuda(gpu_id, non_blocking=True)

                    if frame_idx == 0:
                        print(
                            'Object number: {}. Inference size: {}x{}. Output size: {}x{}.'
                            .format(obj_nums[0],
                                    current_img.size()[2],
                                    current_img.size()[3], int(output_height),
                                    int(output_width)))
                        current_label = sample['current_label'].cuda(
                            gpu_id, non_blocking=True).float()
                        current_label = F.interpolate(current_label,
                                                      size=current_img.size()[2:],
                                                      mode="nearest")
                        # add reference frame
                        engine.add_reference_frame(current_img,
                                                   current_label,
                                                   frame_step=0,
                                                   obj_nums=obj_nums)
                    else:
                        print('Processing image {}...'.format(img_name))
                        # predict segmentation
                        engine.match_propogate_one_frame(current_img)
                        pred_logit = engine.decode_current_logits(
                            (output_height, output_width))
                        pred_prob = torch.softmax(pred_logit, dim=1)
                        pred_label = torch.argmax(pred_prob, dim=1,
                                                  keepdim=True).float()
                        _pred_label = F.interpolate(pred_label,
                                                    size=engine.input_size_2d,
                                                    mode="nearest")
                        # update memory
                        engine.update_memory(_pred_label)

                        # save results
                        output_mask_path = os.path.join(
                            output_mask_seq_root,
                            img_name.split('.')[0] + '.png')
                        pred_label = pred_label * 255
                        pred_label = Image.fromarray(
                            pred_label.squeeze(0).squeeze(0).cpu().numpy().astype(
                                'uint8')).convert('P')
                        pred_label.save(output_mask_path)

    def inpaint_video(self, video_name, video_fps):
        device = self.device
        self.args.video = f'./frames/{video_name}/images/sequence1'

        img = cv2.imread(f'./frames/{video_name}/images/sequence1/frame_0000.png')
        h, w, _ = img.shape
        if self.args.e2_model == "e2fgvi":
            size = (432, 240)
        elif self.args.set_size:
            size = (self.args.width, self.args.height)
        else:
            size = None

        net = importlib.import_module('model.' + self.args.e2_model)
        model = net.InpaintGenerator().to(device)
        data = torch.load(self.args.ckpt, map_location=device)
        model.load_state_dict(data)
        print(f'Loading e2fgvi model from: {self.args.ckpt}')
        model.eval()

        # prepare datset
        self.args.use_mp4 = True if self.args.video.endswith('.mp4') else False
        print(
            f'Loading videos and masks from: {self.args.video} | INPUT MP4 format: {self.args.use_mp4}'
        )
        
        frames = read_frame_from_videos(self.args)
        frames, size = resize_frames(frames, size)
        h, w = size[1], size[0]
        video_length = len(frames)
        imgs = to_tensors()(frames).unsqueeze(0) * 2 - 1
        frames = [np.array(f).astype(np.uint8) for f in frames]
        
        self.args.mask = f'./frames/{video_name}/masks/sequence1'
        masks = read_mask(self.args.mask, size)
        binary_masks = [
            np.expand_dims((np.array(m) != 0).astype(np.uint8), 2) for m in masks
        ]
        masks = to_tensors()(masks).unsqueeze(0)
        # imgs, masks = imgs.to(device), masks.to(device)
        comp_frames = [None] * video_length

        # completing holes by e2fgvi
        print(f'Start test...')
        for f in tqdm(range(0, video_length, self.neighbor_stride)):
            neighbor_ids = [
                i for i in range(max(0, f - self.neighbor_stride),
                                min(video_length, f + self.neighbor_stride + 1))
            ]
            ref_ids = get_ref_index(f, neighbor_ids, video_length, self.num_ref, self.ref_length)
            selected_imgs = imgs[:1, neighbor_ids + ref_ids, :, :, :]
            selected_masks = masks[:1, neighbor_ids + ref_ids, :, :, :]
            with torch.no_grad():
                masked_imgs = selected_imgs * (1 - selected_masks)
                mod_size_h = 60
                mod_size_w = 108
                h_pad = (mod_size_h - h % mod_size_h) % mod_size_h
                w_pad = (mod_size_w - w % mod_size_w) % mod_size_w
                masked_imgs = torch.cat(
                    [masked_imgs, torch.flip(masked_imgs, [3])],
                    3)[:, :, :, :h + h_pad, :]
                masked_imgs = torch.cat(
                    [masked_imgs, torch.flip(masked_imgs, [4])],
                    4)[:, :, :, :, :w + w_pad]
                masked_imgs = masked_imgs.to(device)
                pred_imgs, _ = model(masked_imgs, len(neighbor_ids))
                pred_imgs = pred_imgs[:, :, :h, :w]
                pred_imgs = (pred_imgs + 1) / 2
                pred_imgs = pred_imgs.cpu().permute(0, 2, 3, 1).numpy() * 255
                for i in range(len(neighbor_ids)):
                    idx = neighbor_ids[i]
                    img = np.array(pred_imgs[i]).astype(
                        np.uint8) * binary_masks[idx] + frames[idx] * (
                            1 - binary_masks[idx])
                    if comp_frames[idx] is None:
                        comp_frames[idx] = img
                    else:
                        comp_frames[idx] = comp_frames[idx].astype(
                            np.float32) * 0.5 + img.astype(np.float32) * 0.5

        # saving videos
        print('Saving videos...')
        save_dir_name = 'results'
        ext_name = '_results.mp4'
        save_base_name = self.args.video.split('/')[-1]
        save_name = save_base_name + ext_name
        if not os.path.exists(save_dir_name):
            os.makedirs(save_dir_name)
        save_path = os.path.join(save_dir_name, save_name)
        writer = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*"mp4v"),
                                video_fps, size)
        for f in range(video_length):
            comp = comp_frames[f].astype(np.uint8)
            writer.write(cv2.cvtColor(comp, cv2.COLOR_BGR2RGB))
        writer.release()
        print(f'Finish test! The result video is saved in: {save_path}.')
    
    
    def predict(self, video_path, points):
        strat_time = time.time()

        cap = cv2.VideoCapture(video_path)
    
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        video_fps = int(cap.get(cv2.CAP_PROP_FPS))
        
        print(total_frames, video_fps)
        video_name = video_path.split("/")[-1].split(".")[0]
        output_path = f'./frames/{video_name}/images/sequence1'
        
        print(f"Process video {video_name}")
        os.makedirs(output_path, exist_ok=True)
        
        frame_index = 0
        while frame_index < total_frames:
            ret, frame = cap.read()
            image_path = os.path.join(output_path, f"frame_{frame_index:04d}.png")
            cv2.imwrite(image_path, frame)
            frame_index += 1

        cap.release()
        
        ##SAM
        print("SAM")
        
        init_mask_path = f'./frames/{video_name}/masks/sequence1'
        os.makedirs(init_mask_path, exist_ok=True)
        image_list = os.listdir(output_path)
        image_list = sorted(image_list)
        init_image = image_list[0]
        img = cv2.imread(os.path.join(output_path, init_image))

        # cv2.polylines(img, [points], isClosed=True, color=(0, 255, 0), thickness=20)
        # print(os.path.join(init_mask_path, init_image))
        # cv2.imwrite(os.path.join(init_mask_path, init_image), img)

        init_mask = self.segment_with_point(img, points)
        h, w = init_mask.shape[-2:]
        init_mask = init_mask.reshape(h, w, 1)
        init_mask = init_mask.astype(np.int8) * 255
        print(np.unique(init_mask))
        cv2.imwrite(os.path.join(init_mask_path, init_image), init_mask)
        
        ##AOT
        print("AOT")

        self.segment_video(video_name)

        ##video inpaint
        print("Video Inpainting")
        gc.collect()
        torch.cuda.empty_cache()
        time.sleep(2)
        self.inpaint_video(video_name, video_fps)

        end_time = time.time()
        print(f'{total_frames / (end_time - strat_time)} frames/s')
        
        
if __name__ == "__main__":
    
    # point = np.array([[600, 450]])
    point = np.array([[800, 450]])
    model = ikunet(sam_checkpot, sam_model_type, aot_ckpt, device)
    model.predict("./videos/test.mp4", point)