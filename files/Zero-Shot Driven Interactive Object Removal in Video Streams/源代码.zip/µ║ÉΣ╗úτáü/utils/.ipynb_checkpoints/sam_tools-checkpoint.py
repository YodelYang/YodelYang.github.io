from segment_anything import sam_model_registry, SamPredictor

