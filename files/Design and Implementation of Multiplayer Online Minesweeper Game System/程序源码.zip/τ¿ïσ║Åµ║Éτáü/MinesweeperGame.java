import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import static spark.Spark.*;

public class MinesweeperGame {
    private static final int SIZE = 10;
    private static final int MINE_COUNT = 20;
    private static int[][] board;
    private static Set<Cell> openedCells = new HashSet<>();
    private static Set<Cell> markedCells = new HashSet<>();
    private static Object lock = new Object();

    public static void main(String[] args) {
        initBoard();

        staticFileLocation("/public");

        get("/", (request, response) -> renderBoard());

        post("/open/:x/:y", (request, response) -> {
            int x = Integer.parseInt(request.params(":x"));
            int y = Integer.parseInt(request.params(":y"));
            boolean mark = Boolean.parseBoolean(request.queryParams("mark"));

            synchronized (lock) {
                if (mark) {
                    markCell(x, y);
                } else {
                    openCell(x, y);
                }
            }

            return renderBoard();
        });
    }

    private static void initBoard() {
        board = new int[SIZE][SIZE];
        Random random = new Random();
        Set<Integer> minePositions = new HashSet<>();

        while (minePositions.size() < MINE_COUNT) {
            int pos = random.nextInt(SIZE * SIZE);
            minePositions.add(pos);
        }

        for (int pos : minePositions) {
            int x = pos / SIZE;
            int y = pos % SIZE;
            board[x][y] = -1;
        }
    }

    private static int getAroundMineCount(int x, int y) {
        int count = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int newX = x + i;
                int newY = y + j;
                if (newX >= 0 && newX < SIZE && newY >= 0 && newY < SIZE) {
                    if (board[newX][newY] == -1 || board[newX][newY] == -2 || board[newX][newY] == -3) {
                        count++;
                    }
                }
            }
        }
        return count;
    }

    private static void openCell(int x, int y) {
        Cell cell = new Cell(x, y);
        if (openedCells.contains(cell) || markedCells.contains(cell)) {
            return;
        }

        openedCells.add(cell);
        int aroundMineCount = getAroundMineCount(x, y);

        if (board[x][y] == -1) {
            board[x][y] = -3;
            openedCells.clear();
            for (int i = 0; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    if (board[i][j] == -1) {
                        board[i][j] = -2;
                    } else if (board[i][j] == -3) {
                        board[i][j] = -3;
                    } else {
                        board[i][j] = getAroundMineCount(i, j);
                    }
                    openedCells.add(new Cell(i, j));
                }
            }
            throw new GameOverException();
        } else if (aroundMineCount > 0) {
            board[x][y] = aroundMineCount;
        } else {
            board[x][y] = 0;
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    int newX = x + i;
                    int newY = y + j;
                    if (newX >= 0 && newX < SIZE && newY >= 0 && newY < SIZE) {
                        openCell(newX, newY);
                    }
                }
            }
        }
    }

    private static void markCell(int x, int y) {
        Cell cell = new Cell(x, y);
        if (markedCells.contains(cell)) {
            openedCells.remove(cell);
            markedCells.remove(cell);
        } else if (openedCells.contains(cell)) {
            return;
        } else {
            openedCells.add(cell);
            markedCells.add(cell);
        }
    }

    private static String renderBoard() {
        StringBuilder html = new StringBuilder("<html><head><title>扫雷游戏</title></head><body><table>");

        for (int i = 0; i < SIZE; i++) {
            html.append("<tr>");
            for (int j = 0; j < SIZE; j++) {
                Cell cell = new Cell(i, j);
                html.append("<td><img src=\"/static/image/");
                if (openedCells.contains(cell)) {
                    if (markedCells.contains(cell)) {
                        html.append("mark.gif");
                    } else if (board[i][j] == 0) {
                        html.append("empty.gif");
                    } else if (board[i][j] > 0) {
                        html.append(board[i][j]).append(".gif");
                    } else if (board[i][j] == -2) {
                        html.append("mine.gif");
                    } else if (board[i][j] == -3) {
                        html.append("mine2.gif");
                    }
                } else {
                    html.append("unopened.gif");
                }
                html.append("\" width=\"30\" height=\"30\"");
                html.append(" data-x=\"").append(i).append("\"");
                html.append(" data-y=\"").append(j).append("\"");
                html.append(" onclick=\"openCell(this)\"");
                html.append(" oncontextmenu=\"event.preventDefault(); markCell(this);\"");
                html.append("/></td>");
            }
            html.append("</tr>");
        }

        html.append("</table>");
        html.append("<script>");
        html.append("function openCell(cell) {");
        html.append("fetch('/open/' + cell.dataset.x + '/' + cell.dataset.y, { method: 'POST' })");
        html.append(".then(function(response) { return response.text(); })");
        html.append(".then(function(html) { document.body.innerHTML = html; })");
        html.append("}");

        html.append("function markCell(cell) {");
        html.append("fetch('/open/' + cell.dataset.x + '/' + cell.dataset.y + '?mark=true', { method: 'POST' })");
        html.append(".then(function(response) { return response.text(); })");
        html.append(".then(function(html) { document.body.innerHTML = html; })");
        html.append("}");
        html.append("</script>");
        html.append("</body></html>");

        return html.toString();
    }

    private static class Cell {
        private int x;
        private int y;

        public Cell(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + x;
            result = prime * result + y;
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null || getClass() != obj.getClass())
                return false;
            Cell other = (Cell) obj;
            return x == other.x && y == other.y;
        }
    }

    private static class GameOverException extends RuntimeException {
    }
}
