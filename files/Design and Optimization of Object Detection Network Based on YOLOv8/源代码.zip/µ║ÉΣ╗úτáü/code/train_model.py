from ultralytics import YOLO

# Load a model
model = YOLO("yolov8n.pt")  # load a pretrained model (recommended for training)

# Train the model with 2 GPUs
results = model.train(
    data="coco.yaml",
    batch=512,
    epochs=10,
    imgsz=640,
    device=[0, 1, 2, 3, 4, 5, 6, 7],
    optimizer="SGD",
    lr0=0.0001,
    plots=True,
    fna=False,
)
