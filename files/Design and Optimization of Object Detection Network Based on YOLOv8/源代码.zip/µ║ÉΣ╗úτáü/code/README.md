## Setup

```
conda create -n detector python=3.9
conda activate detector
pip install torch torchvision ultralytics
```
